#include <controller.h>

int is_start_pulse(int pulse)
{
    if (pulse > 3150 && pulse < 3500)
        return 1;
    return 0;
}

//  from 0 to 112
int8_t get_throttle(ControllerRes& res)
{
    return (res.b[0] & 0b01111111);  
}

// from -7 (left) to 7 (right). Zero is middle 
int8_t get_leftright(ControllerRes& res)
{
    return ((res.b[1] & 0b11110000) >> 4) - 8;  
}

// from -7 (down) to 7 (up). Zero is middle 
int8_t get_updown(ControllerRes& res)
{
    return ((res.b[1] & 0b00001111)) - 8;  
}

// 0 or 1 
int8_t get_left(ControllerRes& res)
{
    return (res.b[3] & 0b00100000) >> 5;  
}

// 0 or 1 
int8_t get_right(ControllerRes& res)
{
    return (res.b[3] & 0b10000000) >> 7;  
}

// 0 or 1 
int8_t get_photo(ControllerRes& res)
{
    return (res.b[2] & 0b00000010) >> 1;  
}

// 0 or 1 
int8_t get_video(ControllerRes& res)
{
    return (res.b[2] & 0b00010000) >> 4;  
}

// 0 or 1 
int8_t get_light(ControllerRes& res)
{
    return res.b[2] & 0b00000001;  
}

// 0 or 1 
int8_t get_b1(ControllerRes& res)
{
    return (res.b[3] & 0b00010000) >> 4;  
}

// 0 or 1 
int8_t get_b2(ControllerRes& res)
{
    return (res.b[3] & 0b01000000) >> 6;  
}

int controller_decode(decode_results results, ControllerRes& res)
{ 
//    Serial.println(results.rawlen);
//    for (int i = 0; i < results.rawlen; i++)
//    {
//        Serial.print(results.rawbuf[i]);
//        Serial.print(" ");
//    }
//    Serial.println(""); 
//    Serial.println(results.value);

    int start_offset = -1;
    if (results.rawlen == 34 && is_start_pulse(results.rawbuf[0]))
    {
        start_offset = 2;
    }
    else
    {
        for(int i = 0; i < (results.rawlen - 34); i++)
        {
            if (is_start_pulse(results.rawbuf[i]))
            {
                if (is_start_pulse(results.rawbuf[i + 34]))
                {
                    start_offset = i + 2;
                } 
            }
        }
    }
      
    if (-1 == start_offset)
        return -1;

    for (int i = 0; i < 4; i++)
    {
        res.b[i] = 0;
        for (int j = 0; j < 8; j++)
        {
            int tmp = results.rawbuf[start_offset + i * 8 + j];
            if (tmp > 7 && tmp < 20)
            {
//                Serial.print("0");
                res.b[i] = res.b[i] + (0 << (7 - j));
            }
            else if (tmp >= 20 && tmp < 40)
            {
//                Serial.print("1");
                res.b[i] = res.b[i] + (1 << (7 - j));
            }
            else
            {
                return -1;
            }
        }
//        Serial.println("");
//        Serial.print(i);
//        Serial.print(":");
//        Serial.println(res.b[i], HEX);
    }    
//    Serial.println("");

    res.throttle = get_throttle(res);
    res.leftright = get_leftright(res);
    res.updown = get_updown(res);
    res.left = get_left(res);
    res.right = get_right(res);
    res.photo = get_photo(res);
    res.light = get_light(res);
    res.video = get_video(res);
    res.b1 = get_b1(res);
    res.b2 = get_b2(res);

    return 0;
}


