#ifndef controller_h
#define controller_h

#include <IRremote.h>

typedef struct
{
    unsigned char b[4];
    int8_t throttle;
    int8_t leftright;
    int8_t updown;
    int8_t left;
    int8_t right;
    int8_t photo;
    int8_t light;
    int8_t video;
    int8_t b1;
    int8_t b2;
} ControllerRes;

int controller_decode(decode_results results, ControllerRes& res);

#endif
