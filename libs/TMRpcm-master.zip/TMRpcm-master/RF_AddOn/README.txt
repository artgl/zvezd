The addon receiver library has now been replaced with the RF24Audio library.

Documentation: http://tmrh20.github.io/

Downloads:

Audio Library:      https://github.com/TMRh20/RF24Audio/archive/master.zip 
Core Radio Library: https://github.com/TMRh20/RF24/archive/master.zip
